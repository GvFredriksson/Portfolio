#ifndef SPARTICLE
#define SPARTICLE

struct particle{
    double x, y;
    double xvel, yvel;
    double xforce, yforce;
    double mass;
};

#endif